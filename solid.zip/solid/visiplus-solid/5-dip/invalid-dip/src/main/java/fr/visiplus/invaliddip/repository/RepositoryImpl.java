package fr.visiplus.invaliddip.repository;

public class RepositoryImpl {

	public String getData() {
		return "data";
	}
	
	
}
