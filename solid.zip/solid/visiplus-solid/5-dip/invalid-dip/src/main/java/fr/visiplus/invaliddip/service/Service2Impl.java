package fr.visiplus.invaliddip.service;

public class Service2Impl {
	
	public String getData() {
		return "anoter data";
	}

}
