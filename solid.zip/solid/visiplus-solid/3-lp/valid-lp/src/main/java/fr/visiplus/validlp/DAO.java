package fr.visiplus.validlp;

import java.util.List;

public interface DAO<T> {
	
	public List<T> getData();

}
