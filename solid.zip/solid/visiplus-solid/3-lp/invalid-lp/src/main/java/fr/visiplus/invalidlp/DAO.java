package fr.visiplus.invalidlp;

import java.util.List;

public interface DAO {

	public List<User> getDataFromFile();
	
}
