package com.visiplus.isp;

public class Contractor implements IContractor {

	public String getName() {
		return "charles";
	}

	public String getOriginalCompany() {
		return "Enterprise1";
	}

}
