package com.visiplus.isp;

public class Employee implements Person {

	public String getName() {
		return "eric";
	}

}
