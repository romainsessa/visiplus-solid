package com.visiplus.isp;

public class Director implements IDirector {

	public Integer getCA() {
		return 1000000;
	}

	public String getName() {
		return "didier";
	}

}
