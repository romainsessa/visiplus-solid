package fr.visiplus.invalidisp;

public interface Human {

	public void display();

	public void makeDirectorStuff() throws Exception;

}
