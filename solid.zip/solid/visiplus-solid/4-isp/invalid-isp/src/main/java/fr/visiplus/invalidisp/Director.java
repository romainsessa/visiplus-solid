package fr.visiplus.invalidisp;

public class Director implements Human {

	public void display() {
		System.out.println("I'm a director");
	}

	public void makeDirectorStuff() throws Exception {
		System.out.println("that's my job!");
	}

}
