package fr.visiplus.sharedcomponent;

public class SharedService {

	public String getSharedValue() {
		return "shared value";
	}
	
}
