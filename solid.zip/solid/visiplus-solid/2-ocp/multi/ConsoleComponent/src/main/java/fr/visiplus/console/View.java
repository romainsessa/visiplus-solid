package fr.visiplus.console;

public class View {

	public void display(String text) {
		System.out.println(text);
	}
	
}
