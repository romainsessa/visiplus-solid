package fr.visiplus.validocp;

public enum UserType {
	USER,
	ADMIN
}
