package fr.visiplus.invalidocp;

public enum UserType {
	USER,
	ADMIN
}
