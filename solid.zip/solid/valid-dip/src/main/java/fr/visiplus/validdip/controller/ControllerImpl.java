package fr.visiplus.validdip.controller;

import fr.visiplus.validdip.service.IService;
import fr.visiplus.validdip.view.ConsoleView;

public class ControllerImpl implements IController {
	
	private IService service;
	
	public void setService(IService service) {
		this.service = service;
	}
	
	public void execute() {
		
		String data = service.execute();
		ConsoleView.display(data);
		
	}

}
