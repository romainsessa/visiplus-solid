package fr.visiplus.validdip;

import fr.visiplus.validdip.controller.IController;
import fr.visiplus.validdip.factory.Factory;
import fr.visiplus.validdip.repository.IRepository;
import fr.visiplus.validdip.service.IService;

public class Main {

	public static void main(String[] args) {

		IRepository repository = Factory.getRepository("repositoryimpl");
		IService service = Factory.getService("otherserviceimpl");
		service.setRepository(repository);
		
		IController controller = Factory.getController("controllerimpl");
		controller.setService(service);
		
		controller.execute();
		
		
		
	}

}
