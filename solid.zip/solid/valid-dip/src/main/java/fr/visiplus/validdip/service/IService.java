package fr.visiplus.validdip.service;

import fr.visiplus.validdip.repository.IRepository;

public interface IService {
	
	public String execute();
	
	public void setRepository(IRepository repository);

}
