package fr.visiplus.validdip.service;

import fr.visiplus.validdip.repository.IRepository;

public class ServiceImpl implements IService {

	IRepository repository;
	
	public void setRepository(IRepository repository) {
		this.repository = repository;
	}
	
	public String execute() {
		return repository.getData().toUpperCase();
	}
	
	

}
