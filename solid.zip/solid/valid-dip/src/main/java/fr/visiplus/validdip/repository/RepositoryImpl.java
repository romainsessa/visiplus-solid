package fr.visiplus.validdip.repository;

public class RepositoryImpl implements IRepository {

	public String getData() {
		return "data";
	}

}
