package fr.visiplus.validdip.service;

import fr.visiplus.validdip.repository.IRepository;

public class OtherServiceImpl implements IService {

	IRepository repository;
	
	public String execute() {
		return repository.getData().toLowerCase();
	}

	public void setRepository(IRepository repository) {
		this.repository = repository;
	}

}
