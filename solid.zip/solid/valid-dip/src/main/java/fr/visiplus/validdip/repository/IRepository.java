package fr.visiplus.validdip.repository;

public interface IRepository {
	
	public String getData();

}
