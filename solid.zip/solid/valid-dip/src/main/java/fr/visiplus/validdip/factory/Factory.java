package fr.visiplus.validdip.factory;

import fr.visiplus.validdip.controller.ControllerImpl;
import fr.visiplus.validdip.controller.IController;
import fr.visiplus.validdip.repository.IRepository;
import fr.visiplus.validdip.repository.RepositoryImpl;
import fr.visiplus.validdip.service.IService;
import fr.visiplus.validdip.service.OtherServiceImpl;
import fr.visiplus.validdip.service.ServiceImpl;

public class Factory {
	
	public static IService getService(String criteria) {
		
		if(criteria.equals("serviceimpl")) {
			return new ServiceImpl();
		} else if(criteria.equals("otherserviceimpl")) {
			return new OtherServiceImpl();
		}
		return null;
	}
	
	public static IRepository getRepository(String criteria) {
		if(criteria.equals("repositoryimpl")) {
			return new RepositoryImpl();
		}
		return null;
	}
	
	public static IController getController(String criteria) {
		if(criteria.equals("controllerimpl")) {
			return new ControllerImpl();
		}
		return null;
	}

}
