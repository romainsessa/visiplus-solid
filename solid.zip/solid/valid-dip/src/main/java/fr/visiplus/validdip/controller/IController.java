package fr.visiplus.validdip.controller;

import fr.visiplus.validdip.service.IService;

public interface IController {

	public void setService(IService service);
	
	public void execute();
	
}
