package fr.visiplus.invaliddip.controller;

import fr.visiplus.invaliddip.service.OtherServiceImpl;
import fr.visiplus.invaliddip.view.ConsoleView;

public class ControllerImpl {
	
	public void execute() {
		
		OtherServiceImpl service = new OtherServiceImpl();
		ConsoleView.display(service.execute());
		
	}

}
