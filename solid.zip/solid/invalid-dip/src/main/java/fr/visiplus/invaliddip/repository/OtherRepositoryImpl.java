package fr.visiplus.invaliddip.repository;

public class OtherRepositoryImpl {

	public int getData() {
		return 10;
	}
	
	
}
