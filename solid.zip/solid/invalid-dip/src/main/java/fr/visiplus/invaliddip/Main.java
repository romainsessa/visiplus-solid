package fr.visiplus.invaliddip;

import fr.visiplus.invaliddip.controller.ControllerImpl;

public class Main {

	public static void main(String[] args) {
		
		ControllerImpl ctl = new ControllerImpl();
		ctl.execute();
		
	}
	
}
