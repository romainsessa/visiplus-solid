package fr.visiplus.invaliddip.service;

import fr.visiplus.invaliddip.repository.RepositoryImpl;

public class OtherServiceImpl {
	
	public String execute() {
		
		RepositoryImpl repository = new RepositoryImpl();
		return repository.getData().toLowerCase();
		
	}

}
