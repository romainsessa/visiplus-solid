package fr.visiplus.sharedcomponent;

public class SharedService {

	private String sharedValue = "a shared value";
	
	public String getSharedValue() {
		return this.sharedValue;
	}
	
	
}
