package fr.visiplus.consolecomponent;

import fr.visiplus.sharedcomponent.SharedService;

public class ConsoleApp {

	public static void main(String[] args) {
		
		SharedService service = new SharedService();
		String value = service.getSharedValue();
		
		System.out.println(value);

	}

}
