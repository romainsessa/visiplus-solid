package fr.visiplus.validdip2.repository.implementations;

import fr.visiplus.validdip2.repository.interfaces.IRepository;

public class RepositoryImpl implements IRepository {

	public String getData() {
		return "Data";
	}

}
