package fr.visiplus.validdip2.service.interfaces;

public interface IService {
	
	public String execute();

}
