package fr.visiplus.validdip2.repository.interfaces;

public interface IRepository {
	
	public String getData();

}
