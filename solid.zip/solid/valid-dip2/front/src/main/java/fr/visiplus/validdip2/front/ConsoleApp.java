package fr.visiplus.validdip2.front;

import fr.visiplus.validdip2.repository.implementations.RepositoryImpl;
import fr.visiplus.validdip2.repository.interfaces.IRepository;
import fr.visiplus.validdip2.service.implementations.ServiceImpl;
import fr.visiplus.validdip2.service.interfaces.IService;

public class ConsoleApp {

	public static void main(String[] args) {
		
		IRepository repository = new RepositoryImpl();
		IService service = new ServiceImpl(repository);
		
		System.out.println(service.execute());
		
		
	}
	
}
