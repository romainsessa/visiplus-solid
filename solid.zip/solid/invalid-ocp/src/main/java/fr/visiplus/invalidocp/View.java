package fr.visiplus.invalidocp;

public class View {
	
	public void display(User user) {
		
		System.out.println("Welcome User ! " + user.getUsername());
		
		if(user.getType().equals(UserType.ADMIN)) {
			System.out.println("Welcome Admin ! " + user.getUsername());
		}
		
	}

}
