package fr.visiplus.validlp;

public class Main {

	public static void main(String[] args) {
		
		DAO dao = new MySQLUserDAO();
		dao.getData().forEach(System.out::println);
		
		dao = new FileRoleDAO();
		dao.getData().forEach(System.out::println);

		
	}
	
}
