package fr.visiplus.validlp;

import java.util.ArrayList;
import java.util.List;

public class FileUserDAO implements DAO<User> {

	public List<User> getData() {
		// simulation de la lecture d'un fichier
		List<User> users = new ArrayList<User>();
		users.add(new User("robert"));
		users.add(new User("romain"));
		return users;
	}

}
