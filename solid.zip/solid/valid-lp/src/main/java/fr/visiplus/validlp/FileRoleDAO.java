package fr.visiplus.validlp;

import java.util.ArrayList;
import java.util.List;

public class FileRoleDAO implements DAO<Role>{

	@Override
	public List<Role> getData() {
		// simulation de la lecture d'un fichier
		List<Role> roles = new ArrayList<>();
		roles.add(new Role("user"));
		roles.add(new Role("admin"));
		return roles;	
		
	}

}
