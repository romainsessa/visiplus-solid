package fr.visiplus.validlp;

import java.util.ArrayList;
import java.util.List;

public class MySQLUserDAO implements DAO<User> {

	@Override
	public List<User> getData() {
		// simulation d'un appel à la bdd
		List<User> users = new ArrayList<User>();
		users.add(new User("robert from db"));
		users.add(new User("romain from db"));
		return users;
	}

}
