package fr.visiplus.validocp;

public interface View {

	public void display(User user);
	
}
