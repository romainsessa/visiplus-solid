package fr.visiplus.validocp;

public class User {
	
	private String userName;
	private UserType userType;
	
	public String getUserName() {
		return userName;
	}
	
	public UserType getUserType() {
		return userType;
	}
	
	public User(String username, UserType type) {
		this.userName = username;
		this.userType = type;
	}

}
