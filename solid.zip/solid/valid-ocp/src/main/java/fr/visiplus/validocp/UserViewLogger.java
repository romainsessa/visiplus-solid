package fr.visiplus.validocp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class UserViewLogger implements View {

	public static Logger logger = LoggerFactory.getLogger(UserViewLogger.class);
	
	public void display(User user) {
		logger.info(user.getUserName());		
	}

}
