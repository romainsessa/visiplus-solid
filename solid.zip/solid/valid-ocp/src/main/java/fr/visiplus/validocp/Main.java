package fr.visiplus.validocp;

public class Main {

	public static void main(String[] args) {

		User user = new User("robert", UserType.USER);
		View view = new UserViewLogger();
		Controller controller = new Controller(user, view);
		controller.execute();
		
	}

}
