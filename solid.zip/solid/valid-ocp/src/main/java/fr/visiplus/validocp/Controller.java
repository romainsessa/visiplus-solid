package fr.visiplus.validocp;

public class Controller {
	
	private User user;
	private View view;
	
	public Controller(User user, View view) {
		this.user = user;
		this.view = view;		
	}
	
	public void execute() {
		this.view.display(user);
	}

}
