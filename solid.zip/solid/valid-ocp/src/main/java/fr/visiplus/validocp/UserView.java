package fr.visiplus.validocp;

public class UserView implements View {

	public void display(User user) {
		System.out.println(user.getUserName());
	}

}
