package fr.visiplus.invalidlp;

import java.util.ArrayList;
import java.util.List;

public class MySQLDAO extends FileDAO {

	public List<User> getDataFromDb() {
		
		// simulation d'un appel à la base de données
		List<User> users = new ArrayList<>();
		users.add(new User("user 1 from db"));
		users.add(new User("user 2 from db"));
		
		return users;		
	}
	
	
}
