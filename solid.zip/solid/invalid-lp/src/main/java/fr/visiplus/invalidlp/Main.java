package fr.visiplus.invalidlp;

import java.util.List;

public class Main {

	public static void main(String[] args) {
		
		DAO fileDao = new FileDAO();
		List<User> users = fileDao.getData();
		users.forEach(System.out::println);
		
		MySQLDAO mysqlDao = new MySQLDAO();
		mysqlDao.getDataFromDb().forEach(System.out::println);

	}

}
