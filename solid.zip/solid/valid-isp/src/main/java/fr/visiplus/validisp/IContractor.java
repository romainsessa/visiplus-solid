package fr.visiplus.validisp;

public interface IContractor extends Person {
	
	public String getOriginalCompagny();

}
