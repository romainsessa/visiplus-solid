package fr.visiplus.validisp;

public interface IDirector {

	public int getCA();
	
}
