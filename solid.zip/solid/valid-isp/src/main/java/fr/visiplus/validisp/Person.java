package fr.visiplus.validisp;

public interface Person {
	
	public String getName();

}
