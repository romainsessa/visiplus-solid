package fr.visiplus.invalidisp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Employee implements Human {

	public static Logger logger = LoggerFactory.getLogger(Employee.class);
	
	public void display() {
		logger.info("I'm an employee");
	}

	public void makeDirectorStuff() throws Exception {
		throw new Exception("I'm not a director");
	}

}
