package fr.visiplus.invalidisp;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Director implements Human {

	public static Logger logger = LoggerFactory.getLogger(Director.class);
	
	public void display() {
		logger.info("I'm a Director");
	}

	public void makeDirectorStuff() throws Exception {
		logger.info("I'm happy to work as a Director");
	}

}
