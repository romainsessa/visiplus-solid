package fr.visiplus.invalidisp;

public class Contractor implements Human {

	public void display() {
		// TODO Auto-generated method stub
		
	}

	public void makeDirectorStuff() throws Exception {
		// TODO Auto-generated method stub
		
	}

}
