package com.visiplus.ocp;

public class User {

	private UserType type;
	private String username;
	
	public UserType getType() {
		return type;
	}
	
	public String getUsername() {
		return username;
	}
	
	public User(String username, UserType type) {
		this.username = username;
		this.type = type;
	}
	
}
