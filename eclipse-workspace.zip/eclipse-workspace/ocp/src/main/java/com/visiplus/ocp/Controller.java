package com.visiplus.ocp;

public class Controller {
	
	private View view;
	private User currentUser;

	public Controller(View view, User admin) {
		this.view = view;
		this.currentUser = admin;
	}
	
	public void execute() {
		this.view.display(currentUser);
	}
	
}
