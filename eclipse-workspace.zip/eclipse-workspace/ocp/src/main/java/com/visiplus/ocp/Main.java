package com.visiplus.ocp;

public class Main {

	public static void main(String[] args) {

			User admin = new User("user", UserType.USER);
			View view = new View();
			Controller controller = new Controller(view, admin);
			controller.execute();

		
	}

}
