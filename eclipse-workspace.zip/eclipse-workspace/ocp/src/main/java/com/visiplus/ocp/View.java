package com.visiplus.ocp;

public class View {

	public void display(User currentUser) {

		if(currentUser.getType().equals(UserType.ADMIN)) {
			System.out.println("Welcome Admin");
		}
		
	}

}
