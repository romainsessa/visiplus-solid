package com.visiplus.ocp;

public enum UserType {
	USER,
	ADMIN
}
