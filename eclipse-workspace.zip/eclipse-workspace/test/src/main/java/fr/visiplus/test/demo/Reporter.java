package fr.visiplus.test.demo;

public class Reporter {

	public int getHourInContract(Employee e) {
		return e.getHoursInContract();
	}
	
}
