package fr.visiplus.test.demo;

public class Employee {
	
	private int nbWorkedHours = 40;
	private int priceHour = 100;
	private int hoursInContract = 35;
	
	public int getNbWorkedHours() {
		return nbWorkedHours;
	}
	
	public int getPriceHour() {
		return priceHour;
	}
	
	public int getHoursInContract() {
		return hoursInContract;
	}
	
}
