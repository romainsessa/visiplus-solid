package fr.visiplus.test.demo;

public class Main {

	public static void main(String[] args) {
		
		Employee e = new Employee();
		Calculator calc = new Calculator();
		Reporter reporter = new Reporter();
		
		int hour = reporter.getHourInContract(e);
		System.out.println("From Employee point of view : " + hour);
		
		int pay = calc.calculatePay(e);
		System.out.println("From HR point of view pay is : " + pay);
	}
	
}
