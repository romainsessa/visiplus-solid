package fr.visiplus.test.demo;

public class Calculator {
	
	public int calculatePay(Employee e) {
		
		return e.getPriceHour() * e.getNbWorkedHours();
		
	}

}
