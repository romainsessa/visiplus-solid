package com.visiplus.isp;

public interface IDirector extends Person {
	
	public Integer getCA();

}
