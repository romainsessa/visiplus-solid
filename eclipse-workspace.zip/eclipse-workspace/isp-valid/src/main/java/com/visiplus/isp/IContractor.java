package com.visiplus.isp;

public interface IContractor extends Person {

	public String getOrigineFirm();
	
}
