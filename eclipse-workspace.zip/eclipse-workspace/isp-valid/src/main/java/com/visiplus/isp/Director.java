package com.visiplus.isp;

public class Director implements IDirector {

	public Integer getCA() {
		Integer ca = 1000000;
		return ca;
	}

	public String getName() {
		return "Bob";
	}

}
