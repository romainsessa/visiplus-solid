package com.visiplus.isp;

public interface Person {

	public String getName();
	
}
