package com.visiplus.isp;

public class Contractor implements IContractor {

	public String getName() {
		return "titi";
	}

	public String getOrigineFirm() {
		return "Enterprise1";
	}

}
