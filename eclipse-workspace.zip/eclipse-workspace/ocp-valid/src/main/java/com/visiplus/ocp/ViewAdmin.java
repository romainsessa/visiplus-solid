package com.visiplus.ocp;

public class ViewAdmin implements View {

	public void display(User user) {
		System.out.println("Welcome Admin : "  + user.getUsername());
	}

}
