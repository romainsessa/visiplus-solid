package com.visiplus.ocp;

public class ViewUser implements View {

	public void display(User user) {
		System.out.println("Welcome user : "  + user.getUsername());
	}

}
