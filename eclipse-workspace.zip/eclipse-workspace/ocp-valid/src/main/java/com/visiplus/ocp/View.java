package com.visiplus.ocp;

public interface View {

	public void display(User user);
	
}
