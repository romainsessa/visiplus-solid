package com.visiplus.ocp;

public class Controller {

	private User user;
	private View view;
	
	public Controller(User user, View view) {
		this.user = user;
		this.view = view;
	}
	
	public void execute() {
		view.display(user);
	}
	
}
