package com.visiplus.ocp;

public class Main {

	public static void main(String[] args) {

		User user = new User("basicUser", UserType.USER);
		User admin = new User("basicAdmin", UserType.ADMIN);
		
		View view;
		if(admin.getType().equals(UserType.USER)) {
			view = new ViewUser();
		} else {
			view = new ViewAdmin();
		}
		
		Controller ctl = new Controller(admin, view);
		ctl.execute();
		
		
	}

}
