package com.visiplus.lp;

public class FileDAO {
	
	
	public User getDataFromFile(String path) {
		
		// simule la lecture d'un fichier
		String temp = "toto";
		
		User u = new User();
		u.setUsername(temp);
		
		return u;
		
	}

}
