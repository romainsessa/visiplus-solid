package com.visiplus.lp;

public interface DAO {

	public User getDataFromFile();
	
	
}
