package com.visiplus.lp;

public class Main {
	
	public static void main(String[] args) {
		
		MySQLDAO mysqlDAO = new MySQLDAO();
		mysqlDAO.getDataFromMySQL();
		
		mysqlDAO.getDataFromFile("");
		
	}

}
