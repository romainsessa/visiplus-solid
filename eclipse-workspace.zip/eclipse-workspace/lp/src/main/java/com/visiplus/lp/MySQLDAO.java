package com.visiplus.lp;

public class MySQLDAO extends FileDAO {
	
	public User getDataFromMySQL() {
		
		// simulation lecture base de données
		String temp = "titi";
		
		User u = new User();
		u.setUsername(temp);
		
		return u;
		
	}
	
}
