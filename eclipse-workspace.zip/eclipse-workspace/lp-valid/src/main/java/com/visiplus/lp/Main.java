package com.visiplus.lp;

public class Main {
	
	public static void main(String[] args) {
		
		DAO dao = new DatabaseImpl();
		
		dao.getData();
		
		
	}

}
