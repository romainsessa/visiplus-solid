package com.visiplus.lp;

public interface DAO<T> {
	
	public T getData();

}
