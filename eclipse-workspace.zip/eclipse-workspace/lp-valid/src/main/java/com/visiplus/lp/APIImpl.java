package com.visiplus.lp;

import com.visiplus.lp.data.Role;

public class APIImpl implements DAO<Role> {

	public Role getData() {

		// Simulation de l'appel à une API
		String roleName = "admin";
		Role r = new Role();
		r.setName(roleName);
		
		return r;
	}

	
	
}
