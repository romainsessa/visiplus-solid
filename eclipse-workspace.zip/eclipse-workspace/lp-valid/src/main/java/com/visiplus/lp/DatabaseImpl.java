package com.visiplus.lp;

import com.visiplus.lp.data.User;

public class DatabaseImpl implements DAO<User> {

	public User getData() {
		// simulation d'un appel à la base de données
		String username = "toto";
		
		User user = new User();
		user.setUsername(username);
		
		return user;
	}

}
