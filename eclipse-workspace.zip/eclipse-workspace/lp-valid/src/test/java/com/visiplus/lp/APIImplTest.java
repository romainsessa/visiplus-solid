package com.visiplus.lp;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.visiplus.lp.data.Role;

public class APIImplTest {
	
	@Test
	public void testGetData() {
		
		String expectedRoleName = "admin";
		DAO<Role> apiDao = new APIImpl();
		
		String result = apiDao.getData().getName();
		
		assertEquals(expectedRoleName, result);
		
		
	}

}
