package com.visiplus.consolecomponent;

import com.visiplus.sharedcomponent.SharedService;

public class ConsoleApp {
	
	public static void main(String[] args) {
		
		SharedService service = new SharedService();
		System.out.println(service.getSharedValue());
		
	}

}
