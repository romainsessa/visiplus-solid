package com.visiplus.sharedcomponent;

public class SharedService {
	
	public String getSharedValue() {
		return "sharedValue";
	}

}
