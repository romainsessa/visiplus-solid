package com.visiplus.isp;

public class Director implements Human {

	public void display() {
		System.out.println("I'm a Director");		
	}

	public void makeDirectorStuff() {
		System.out.println("I'm doing Director stuff");
		
	}

}
