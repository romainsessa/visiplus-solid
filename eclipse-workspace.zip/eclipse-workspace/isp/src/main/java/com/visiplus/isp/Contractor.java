package com.visiplus.isp;

public class Contractor implements Human {

	public void display() {
		System.out.println("I'm a Contractor");
	}

	public void makeDirectorStuff() throws Exception {
		throw new Exception("I'm not a Director");		
	}

}
