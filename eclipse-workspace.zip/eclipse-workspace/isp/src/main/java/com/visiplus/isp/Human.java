package com.visiplus.isp;

public interface Human {

	public void display();
	
	public void makeDirectorStuff() throws Exception;
	
}
