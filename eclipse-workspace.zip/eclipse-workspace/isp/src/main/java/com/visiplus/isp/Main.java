package com.visiplus.isp;

import java.util.ArrayList;
import java.util.List;

public class Main {
	
	public static void main(String[] args) throws Exception {
		
		List<Human> poolResources = new ArrayList<Human>();
		
		poolResources.add(new Director());
		poolResources.add(new Employee());
		poolResources.add(new Contractor());
		
		for(Human h : poolResources) {
			h.display();
			h.makeDirectorStuff();
		}
		
		
	}

}
