package com.visiplus.dip.service;

import com.visiplus.dip.repository.RepositoryImpl;

public class ServiceImpl {
	
	public String execute() {
		
		RepositoryImpl repo = new RepositoryImpl();
		return repo.getData();
		
	}

}
