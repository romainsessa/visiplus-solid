package com.visiplus.dip.controller;

import com.visiplus.dip.service.Service2Impl;
import com.visiplus.dip.service.ServiceImpl;
import com.visiplus.dip.view.ConsoleView;

public class ControllerImpl {

	private ConsoleView view;
	
	public ControllerImpl(ConsoleView view) {
		this.view = view;
	}
	
	public void execute() {
		
//		ServiceImpl service = new ServiceImpl();
//		String data = service.execute();
		
		Service2Impl service2 = new Service2Impl();
		String data = service2.getData();
		
		this.view.display(data);	
		
	}
	
	
	
}
