package com.visiplus.dip.service;

public class Service2Impl {
	
	public String getData() {
		return "anoter data";
	}

}
