package com.visiplus.dip;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.visiplus.dip.controller.ControllerImpl;
import com.visiplus.dip.view.ConsoleView;

public class Main {
	
	public static Logger logger = LoggerFactory.getLogger(Main.class);
	
	
	public static void main(String[] args) {
		logger.info("Welcome");
		
		ControllerImpl controller = new ControllerImpl(new ConsoleView());
		controller.execute();
	}

}
