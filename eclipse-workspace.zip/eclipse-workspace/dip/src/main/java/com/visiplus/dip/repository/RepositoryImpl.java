package com.visiplus.dip.repository;

public class RepositoryImpl {

	public String getData() {
		return "data";
	}
	
	
}
